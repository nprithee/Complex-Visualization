// Load in JSON data
async function loadCourses() {
    
    let response = await fetch("data/courses-main.json");
    let data = await response.json();
    displayCourseCatalog(data);
  }
  
  // Display course catalog
  function displayCourseCatalog(data) {
    let catalogContainer = document.getElementById("courseCatalog");
    let title = document.createElement("h1");
    title.innerHTML = "Course Catalog";
    catalogContainer.appendChild(title);
  
    for (let department of data) {
      let departmentTitle = document.createElement("h2");
      departmentTitle.innerHTML = department.subjectName;
      catalogContainer.appendChild(departmentTitle);
  
      for (let course of department.courses) {
        let courseItem = document.createElement("div");
        courseItem.classList.add("course");
  
        let courseInfo = `
          <h3>${course.course}</h3>
          <p><strong>Status:</strong> ${course.status}</p>
          <p><strong>CRN:</strong> ${course.crn}</p>
          <p><strong>Credits:</strong> ${course.credits}</p>
          <p><strong>Instructor:</strong> ${course.instructor}</p>
          <p><strong>Location:</strong> ${course.location}</p>
          <p><strong>Time:</strong> ${course.time}</p>
          <p><strong>Start Date:</strong> ${course.startDate}</p>
          <p><strong>End Date:</strong> ${course.endDate}</p>
          <p><strong>Note:</strong> ${course.note}</p>
        `;
  
        courseItem.innerHTML = courseInfo;
        catalogContainer.appendChild(courseItem);
      }
    }
  }
  
  // Call the function to load and display courses
  loadCourses();
  