import * as d3 from "https://cdn.jsdelivr.net/npm/d3@7/+esm";

async function render(renderElement, data) {
  // Clear the contents of the element. Start fresh!!
  renderElement.innerHTML = "";

  // Get the width and height of the render element
  let dimensions = renderElement.getBoundingClientRect();
  let width = dimensions.width;
  let height = 500;

  // Create an SVG element within the document
  let svg = d3
    .select(renderElement)
    .append("svg")
    .attr("width", width)
    .attr("height", height);

  // Set the margins
  let margin = { top: 50, right: 60, bottom: 120, left: 80 };
  width -= margin.left + margin.right;
  height -= margin.top + margin.bottom;

  // Create scales for the bubble chart
  let xScale = d3.scaleLinear().range([0, width]).domain([0, d3.max(data, d => d.Tenure_Months)]);
  let yScale = d3.scaleLinear().range([height, 0]).domain([0, d3.max(data, d => d.Online_Spend)]);
  let radiusScale = d3.scaleSqrt().range([5, 20]).domain([0, d3.max(data, d => d.Avg_Price)]);

  // Create a legend for colors
  let colorLegend = svg.append("g")
    .attr("transform", `translate(${margin.left}, ${margin.top - 40})`);

  // Add legend circles and labels for Male and Female
  colorLegend.append("circle")
    .attr("cx", 0)
    .attr("cy", 0)
    .attr("r", 10)
    .attr("fill", "steelblue");

  colorLegend.append("text")
    .attr("x", 15)
    .attr("y", 5)
    .text("Male")
    .style("font-size", "12px")
    .attr("alignment-baseline", "middle");

  colorLegend.append("circle")
    .attr("cx", 0)
    .attr("cy", 20)
    .attr("r", 10)
    .attr("fill", "salmon");

  colorLegend.append("text")
    .attr("x", 15)
    .attr("y", 25)
    .text("Female")
    .style("font-size", "12px")
    .attr("alignment-baseline", "middle");

  // Draw bubbles for male customers
  svg.selectAll(".male-bubble")
    .data(data.filter(d => d.Gender === "M"))
    .enter()
    .append("circle")
    .attr("cx", d => xScale(d.Tenure_Months) + margin.left)
    .attr("cy", d => yScale(d.Online_Spend) + margin.top)
    .attr("r", d => radiusScale(d.Avg_Price))
    .attr("fill", "steelblue")
    .attr("opacity", 0.7);

  // Draw bubbles for female customers
  svg.selectAll(".female-bubble")
    .data(data.filter(d => d.Gender === "F"))
    .enter()
    .append("circle")
    .attr("cx", d => xScale(d.Tenure_Months) + margin.left)
    .attr("cy", d => yScale(d.Online_Spend) + margin.top)
    .attr("r", d => radiusScale(d.Avg_Price))
    .attr("fill", "salmon")
    .attr("opacity", 0.7);

  // Add labels
  svg.append("text")
    .attr("transform", `translate(${width / 2 + margin.left},${height + margin.top + 50})`)
    .style("text-anchor", "middle")
    .text("Tenure (Months)");

  svg.append("text")
    .attr("transform", "rotate(-90)")
    .attr("y", margin.left - 30)
    .attr("x", 0 - (height / 2) - margin.top)
    .style("text-anchor", "middle")
    .text("Online Spend");

  // Add legend
  svg.append("text")
    .attr("x", margin.left)
    .attr("y", margin.top - 20)
    .text("Legend")
    .style("font-size", "14px")
    .style("font-weight", "bold");

  // If the browser window changes size, rerender
  window.addEventListener("resize", () => render(el, data));
}

// Load the data from the CSV file
const data = await d3.csv("./data/file.csv");

// Find the element we want to render into
let el = document.querySelector(".chart-graphic");

// Render the bubble chart
render(el, data);
