function render(renderElement, data) {
  renderElement.innerHTML = "";

  let dimensions = renderElement.getBoundingClientRect();
  let width = dimensions.width;
  let height = 400;

  let svg = d3
    .select(renderElement)
    .append("svg")
    .attr("width", "100%")
    .attr("height", height);

  const PADDING = { top: 20, right: 20, bottom: 40, left: 40 };

  let xScale = d3
    .scaleLinear()
    .domain(d3.extent(data, (d) => d.longitude))
    .range([PADDING.left, width - PADDING.right]);

  let yScale = d3
    .scaleLinear()
    .domain(d3.extent(data, (d) => d.latitude))
    .range([height - PADDING.bottom, PADDING.top]);

  svg
    .selectAll("circle")
    .data(data)
    .enter()
    .append("circle")
    .attr("cx", (d) => xScale(d.longitude))
    .attr("cy", (d) => yScale(d.latitude))
    .attr("r", (d) => d.magnitude * 2)
    .classed("earthquake", true);

  svg
    .append("g")
    .attr("transform", `translate(0, ${height - PADDING.bottom})`)
    .call(d3.axisBottom(xScale));

  svg
    .append("g")
    .attr("transform", `translate(${PADDING.left}, 0)`)
    .call(d3.axisLeft(yScale));

  svg
    .append("text")
    .attr("x", width / 2)
    .attr("y", height - 10)
    .attr("text-anchor", "middle")
    .text("Longitude");

  svg
    .append("text")
    .attr("transform", "rotate(-90)")
    .attr("x", -height / 2)
    .attr("y", 15)
    .attr("text-anchor", "middle")
    .text("Latitude");
}


d3.csv('data/earthquakes-japan.csv', function(d) {
  // Convert numeric strings to numbers
  return {
    year: +d.year,
    month: +d.month,
    day: +d.day,
    location: d.location,
    latitude: +d.latitude,
    longitude: +d.longitude,
    magnitude: +d.magnitude
  };
}).then(function(data) {
  let el = document.querySelector(".chart-graphic");
  render(el, data);
  window.addEventListener("resize", () => render(el, data));
});
