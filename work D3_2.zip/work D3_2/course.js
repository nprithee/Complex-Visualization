document.addEventListener('DOMContentLoaded', function () {
    // Load the JSON data
    fetch('http://localhost:8080/course-main.json')
        .then(response => response.json())
        .then(data => renderCatalog(data))
        .catch(error => console.error('Error fetching data:', error));
});

function renderCatalog(data) {
    const catalogContainer = document.getElementById('catalog-container');

    data.forEach(department => {
        const departmentHeading = document.createElement('h2');
        departmentHeading.textContent = department.subjectName;
        catalogContainer.appendChild(departmentHeading);

        department.courses.forEach(course => {
            const courseItem = document.createElement('div');
            courseItem.classList.add('course');

            const courseTitle = document.createElement('p');
            courseTitle.textContent = `Title: ${course.course}`;
            courseItem.appendChild(courseTitle);

            const courseCode = document.createElement('p');
            courseCode.textContent = `Code: ${course.subject}`;
            courseItem.appendChild(courseCode);

            const instructor = document.createElement('p');
            instructor.textContent = `Instructor: ${course.instructor}`;
            courseItem.appendChild(instructor);

            const location = document.createElement('p');
            location.textContent = `Location: ${course.location}`;
            courseItem.appendChild(location);

            const time = document.createElement('p');
            time.textContent = `Time: ${course.time}`;
            courseItem.appendChild(time);

            const note = document.createElement('p');
            note.classList.add('note');
            note.textContent = `Note: ${course.note}`;
            courseItem.appendChild(note);

            catalogContainer.appendChild(courseItem);
        });
    });
}
